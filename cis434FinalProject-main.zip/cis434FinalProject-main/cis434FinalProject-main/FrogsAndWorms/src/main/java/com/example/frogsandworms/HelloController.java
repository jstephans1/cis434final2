package com.example.frogsandworms;

import java.io.File;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class HelloController {

    @FXML
    private ImageView imageView;

    @FXML
    private Text gameText;

    @FXML
    private ToggleGroup radioGroup;

    @FXML
    private RadioButton option1;

    @FXML
    private RadioButton option2;

    @FXML
    private RadioButton option3;
    
    private scene currentScene;
    private SceneManager sceneManager = null;
    @FXML
    public void switchTextAndImage() {
        // Update the text and image based on some logic
    	SwitchScene(1);
   
    }
    
    @FXML
    void Option1 (ActionEvent event) {
    	SwitchScene(currentScene.b1Connect);
    }
    @FXML
    void Option2 (ActionEvent event) {
    	SwitchScene(currentScene.b1Connect);
    }
    @FXML
    void Option3 (ActionEvent event) {
    	SwitchScene(currentScene.b1Connect);
    }
    @FXML
    public void SwitchScene(int sceneID) {
    	if (sceneID == -1) { return; }
    	if (sceneManager == null) {
    		sceneManager = new SceneManager();
    	}
    	currentScene = sceneManager.GetScene(sceneID);
    	LoadScene();
    }
    @FXML
    public void LoadScene() {
    	gameText.setText(currentScene.text);
    	imageView.setImage(currentScene.image);
    	option1.setText(currentScene.btn1);
    	option2.setText(currentScene.btn2);
    	option3.setText(currentScene.btn3);
    }
    
    
}
