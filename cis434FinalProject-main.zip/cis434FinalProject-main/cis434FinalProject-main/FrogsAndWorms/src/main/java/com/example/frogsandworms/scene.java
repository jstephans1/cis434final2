package com.example.frogsandworms;
import javafx.fxml.FXML;
import javafx.scene.image.Image;

public class scene{
	int sceneID;
	public Image image;
	public String text;
	public String btn1;
	public String btn2;
	public String btn3;
	public int b1Connect;
	public int b2Connect;
	public int b3Connect;
	
	public scene() {}
	
	}
