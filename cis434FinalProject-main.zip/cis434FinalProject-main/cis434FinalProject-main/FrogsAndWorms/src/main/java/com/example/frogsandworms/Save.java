package com.example.frogsandworms;

import java.io.Serializable;

public class Save implements Serializable {
    int locationID;
    int enemiesDefeated;
    int intelligence;
    int luck;
    int strength;
    int swordRepair;
    int level;
    int skillPoints;
}
